function search(test){
    nlapiLogExecution('DEBUG', 'GET REQUEST', 'search Reached');
var searchRecords = [];
    var filters = [];
        filters.push(new nlobjSearchFilter('created', null, 'onorafter', "1/1/2017"));
        filters.push(new nlobjSearchFilter('custrecord_fso_status', null, 'noneof', 'closed', 'cancelled'));
        filters.push(new nlobjSearchFilter('custrecord_fso_status', null, 'noneof', 'clone', 'QA Completed'));
        filters.push(new nlobjSearchFilter('custrecord_fso_status', null, 'noneof', 'error', 'template'));
    var columns = [];
        columns.push(new nlobjSearchColumn('name'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_customer'));
        columns.push(new nlobjSearchColumn('custrecord_fso_status'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_subcontract'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_case'));
        columns.push(new nlobjSearchColumn('salesrep', 'custrecord_fajob_customer'));
        columns.push(new nlobjSearchColumn('phone', 'custrecord_fajob_customer'));
        columns.push(new nlobjSearchColumn('custrecord_confirmed_eta'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_date_started'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_date_completed'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_sla_response'));
        columns.push(new nlobjSearchColumn('custrecord_fajob_sla_resolution'));
    var search = nlapiSearchRecord('customrecord_fajob', null, filters, columns);
    if (search){
        for (var i = 0, len = search.length; i < len; i++){
            var searchData = {
                "FSO#" : search[i].getValue('name'),
                "Customer" : search[i].getText('custrecord_fajob_customer'),
                "Main Status" : search[i].getText('custrecord_fso_status') || 'Main Status Not Given',
                "Sub Status" : search[i].getText('custrecord_fajob_subcontract'),
                "Case Number" : search[i].getValue('custrecord_fajob_case'),
                "Customer Name" : search[i].getText('salesrep', 'custrecord_fajob_customer'),
                "Customer Phone" : search[i].getValue('phone', 'custrecord_fajob_customer') || 'Phone Number Not Given',
                "ETA" : search[i].getValue('custrecord_confirmed_eta'),
                "Tech Check In Time" : search[i].getValue('custrecord_fajob_date_started'),
                "Tech Check Out Time" : search[i].getValue('custrecord_fajob_date_completed'),
                "SLA Response Time" : search[i].getValue('custrecord_fajob_sla_response') || 'Response Time Not Entered',
                "SLA Resolution Time" : search[i].getValue('custrecord_fajob_sla_resolution') || 'Resolution Time Not Given'
            }
            searchRecords.push(searchData);
        }
    }
      nlapiLogExecution('DEBUG', 'GET REQUEST', 'search return');
    return searchRecords;
}