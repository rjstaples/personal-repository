function chuckNorrisCsv(test){
	nlapiLogExecution('DEBUG', 'GET REQUEST', 'ChuckNorris Reached');
	var response = nlapiRequestURL('http://api.icndb.com/jokes/random/10', null);
	var jokeObject = JSON.parse(response.getBody());
	var ids = [];
	var jokes = [];
  	var categories = [];
	var x = 0;
	for (var i in jokeObject.value){
		ids[x] = 'id: ' + JSON.stringify(jokeObject.value[i].id) + ',';
      	categories[x] = JSON.stringify(jokeObject.value[i].categories) + ',';
		jokes[x] = JSON.stringify(jokeObject.value[i].joke) + ',';
      if (categories[x] == '[],'){
        categories[x] = 'All Categories,';
        }
      if (categories[x] == '[\"nerdy\"],'){
        categories[x] = 'Nerdy,';
        }
      if (categories[x] == '[\"explicit\"],'){
        categories[x] = 'Explicit,';
        }
      	x++;
	}
  var results = '';
  	//Build static header here using the key names
  	//results = ID, Joke, Category;

  	for (var i in jokeObject.value)
    {
       results = results + ids[i] + categories[i] + jokes[i] + '\n\r';
    }
	nlapiLogExecution('DEBUG', 'GET REQUEST', jokeObject);
	var createFile = nlapiCreateFile('export.csv', 'CSV', results)
	nlapiLogExecution('DEBUG', 'GET REQUEST', categories);
	nlapiSendEmail(76908, 'rjstaples93@gmail.com', 'Test', 'hi', null, null, null, createFile, null, null, null);
	return results;
}