function exportToCsv(request) {
		nlapiLogExecution('DEBUG', 'GET REQUEST', JSON.stringify(request));

	var me = {"name":'Ryan', "age":25, "Car":'ford'};
	var headers = [];
	var values = [];
	var x = 0;
	for (var i in me){
		headers[x] = i + ',';
		values[x] = me[i] + ',';
		x++;
	}
	var createFile = nlapiCreateFile('export.csv', 'CSV', headers[0] + values[0] + headers[1] + values[1] + headers[2] + values[2])
	nlapiLogExecution('DEBUG', 'GET REQUEST', 'Created');
	nlapiSendEmail(76908, 'rjstaples93@gmail.com', 'Test', 'Hello World', null, null, null, null, null, null, null);
	return headers[0] + values[0] + headers[1] + values[1] + headers[2] + values[2];
	//return createFile.getValue;
}