function datatablePopulation(){
	console.log('reached the function')
	nlapiLogExecution('debug', 'get request', 'Exercise Reached')
	var returnobj = [];
	var headerObj = {
		'headerOne': 'Id',
		'headerTwo': 'Name',
		'headerThree': 'Series',
		'headerFour': 'Platform'
	}

	var characterObj = [];
	nlapiLogExecution('debug', 'get Request', 'Variables Created')

		characterObj.push ({
			'id': '1',
			'name': 'Mario',
			'series': 'Super Mario Bros.',
			'platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '2',
			'name': 'Link',
			'series': 'The Legend Of Zelda',
			'Platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '3',
			'name': 'Cloud',
			'series': 'Final Fantasy',
			'platform': 'Sony'
		})
		characterObj.push ({
			'id': '4',
			'name': 'Samus',
			'series': 'Metroid',
			'platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '5',
			'name': 'Shulk',
			'series': 'Xenoblade Chronicles',
			'platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '6',
			'name': 'Ryu',
			'series': 'Street Fighter',
			'platform': '3rd Party'
		})
		characterObj.push ({
			'id': '7',
			'name': 'Villager',
			'series': 'Animal Crossing',
			'platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '8',
			'name': 'Donkey Kong',
			'series': 'Donkey Kong Country',
			'platform': 'Nintendo'
		})
		characterObj.push ({
			'id': '9',
			'name': 'Spyro',
			'series': 'Spyro The Dragon',
			'platform': 'Sony'
		})
		characterObj.push ({
			'id': '10',
			'name': 'Mega Man',
			'series': 'Mega Man',
			'platform': '3rdParty'
		})
		characterObj.push ({
			'id': '11',
			'name': 'Captain Falcon',
			'series': 'F-Zero',
			'platform': 'Nintendo'
		})
		nlapiLogExecution('debug', 'get Request', characterObj.length)
for (var i = 0, len = characterObj.length; i < len; i++){
	var characterData = {
		'Name': characterObj[i].getValue('name'),
		'Series': characterObj[i].getValue('series'),
		'Platform': characterObj[i].getValue('platform')
	}
	returnobj.push(characterData);
}
nlapiLogExecution('debug', 'get Request', 'return Reached')
	return returnobj;
}