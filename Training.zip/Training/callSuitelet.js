 function CallBack() {
     var response;

     var myTokens = {
         "authorization": {
             "consumer_key": "2f2886942fb3a3d64b03573d7eff15b3019f45e443df32a24af8dc3e9c01cf80",
             "consumer_secret": "79f5c0f07ee6e1c535c4f2ef8fb0968fc5e0c0f6e41074c659e49ccf85b7d371",
             "token_id": "96b82112904bff9755a0edfb3c392596168c5aa64946af6acb34924242ed84c4",
             "token_secret": " d9f0643f54c8d715ca4d0c6e204529588ddb05be1322743a11a701e9ceba3e5f",
             "account_id": "3575242_SB1",
             "rest_url": "https://3575242-sb1.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=965&deploy=1",
         }
     }
     response = nlapiRequestURL('https://forms.netsuite.com/app/site/hosting/scriptlet.nl?script=975&deploy=1&compid=3575242_SB1&h=f2f099027efb9d5ebbe8', null, myTokens.getBody())
     return response;
 }
