/*******************************************************************************

 [WORKMARKET OAUTH TOKEN SUITELET.JS]
 Generates an OAuth Token to use with the WorkMarket RESTlet

 * Version 1.0.0 | 08 November 2018
 * Michael Kubala (michael.kubala@globaldataservices.co)

*******************************************************************************/
function generate_oauth_token(request, response){
    var HTTP_METHOD = request.getMethod();    

    var CONSUMER_KEY, CONSUMER_SECRET, TOKEN_ID, TOKEN_SECRET, NETSUITE_ACCOUNT_ID, REST_URL;
    if (HTTP_METHOD == 'GET'){
        CONSUMER_KEY = request.getParameter('consumer_key');
        CONSUMER_SECRET = request.getParameter('consumer_secret');
        TOKEN_ID = request.getParameter('token_id');
        TOKEN_SECRET = request.getParameter('token_secret');
        NETSUITE_ACCOUNT_ID = request.getParameter('account_id');
        REST_URL = request.getParameter('rest_url') + '&deploy=' + request.getParameter('deploy') + '&rf=' + request.getParameter('rf');
    }
    if (HTTP_METHOD == 'POST'){
        var request_body = JSON.parse(request.getBody());
        CONSUMER_KEY = request_body.authorization.consumer_key;
        CONSUMER_SECRET = request_body.authorization.consumer_secret;
        TOKEN_ID = request_body.authorization.token_id;
        TOKEN_SECRET = request_body.authorization.token_secret;
        NETSUITE_ACCOUNT_ID = request_body.authorization.account_id;
        REST_URL = request_body.authorization.rest_url;
    }
    
    var oauth = OAuth({
        consumer: {
            key: CONSUMER_KEY,
            secret: CONSUMER_SECRET
        },
        signature_method: 'HMAC-SHA1',
        realm: NETSUITE_ACCOUNT_ID,
        hash_function: function(base_string, key){
            var hash = CryptoJS.HmacSHA1(base_string, key);
            var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
            return hashInBase64;
        }
    });

    var postdata = null;
    var headers = {
        "Authorization" : oauth.toHeader(oauth.authorize({ url: REST_URL,method: HTTP_METHOD }, { key:TOKEN_ID,secret:TOKEN_SECRET })).Authorization,
        "Content-Type" : "application/json",
        "Cache-Control" : "no-cache"
    };    
    if (HTTP_METHOD == 'POST'){
        delete request_body.authorization;
        postdata = JSON.stringify(request_body);
    }
    nlapiLogExecution("DEBUG", "TEST", REST_URL);
    var restlet_call = nlapiRequestURL(REST_URL, postdata, headers, HTTP_METHOD);
  	 nlapiLogExecution("DEBUG", "TEST", restlet_call.getBody());
    var response_data = 'suiteletCallback' + '(' + restlet_call.getBody() + ')';
    response.write(response_data);
}