/*******************************************************************************
[GET REQUESTS]
Retrieves data from netsuite using routing functions

@parameters {REST} - GET HTTP Request
@returns {object} - JSON object containing response data
*******************************************************************************/
function getData(request){
	nlapiLogExecution('DEBUG', 'GET REQUEST', JSON.stringify(request));
	if (request.rf == null)
	{
		return 'your url must provide a routing function'
	}
	else if (request.rf == 'chuckNorrisJokes') 
	{
		return ChuckNorris();
	}
	else if (request.rf == 'chuckNorrisCsv') 
	{
		return chuckNorrisCsv();
	}
	else if (request.rf == 'export') 
	{
		return exportToCsv();
	}
	else if (request.rf == 'cheese')
	{
		return test_connection();
	}
	else if (request.rf == 'search')
	{
		return search();
	}
	else if (request.rf == 'datatables')
	{
		return datatableExercise();
	}
	else{
		return request.rf;
	}
}

/*******************************************************************************
[POST REQUESTS]
Updates records in netsuite using the Workmarket web hooks

@parameters {REST} - POST HTTP Request
@returns {object} - JSON object containing response data
*******************************************************************************/
function postData(request){
	nlapiLogExecution('DEBUG', 'POST REQUEST', JSON.stringify(request));
	if (request.rf == null)
	{
		return 'your url must provide a routing function'
	}
	else if (request.rf == 'cheese')
	{
		return test_connection();
	}
	else{
		return request.rf;
	}
}
