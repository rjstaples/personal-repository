function test_connection(){
	nlapiLogExecution('DEBUG', 'Routing Function Start', 'test_connection')
	var response = {
		'status': 'success',
		'message': 'The endpoint was successfully calledusing a routing function, authenticated, and returned a response.'
	};
	return response;
}