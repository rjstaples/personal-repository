function getData(request, response)
{
  var xml = '<?xml version="1.0" encoding="utf-8" ?>' + '<message>' + 'Hello World' + '</message>';
  response.write(xml);
  response.setHeader('Custom-Header-Demo', 'Demo');
}